/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QLineEdit *turnos;
    QLabel *label_2;
    QLineEdit *escritorios;
    QLabel *label_3;
    QLineEdit *estaciones;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QTextEdit *imagen;
    QTextEdit *consola;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *aviones;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1335, 773);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 10, 151, 17));
        turnos = new QLineEdit(centralWidget);
        turnos->setObjectName(QStringLiteral("turnos"));
        turnos->setGeometry(QRect(20, 40, 113, 25));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(180, 10, 161, 17));
        escritorios = new QLineEdit(centralWidget);
        escritorios->setObjectName(QStringLiteral("escritorios"));
        escritorios->setGeometry(QRect(190, 40, 113, 25));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(510, 10, 151, 17));
        estaciones = new QLineEdit(centralWidget);
        estaciones->setObjectName(QStringLiteral("estaciones"));
        estaciones->setGeometry(QRect(530, 40, 113, 25));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(860, 40, 141, 25));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(290, 80, 89, 25));
        imagen = new QTextEdit(centralWidget);
        imagen->setObjectName(QStringLiteral("imagen"));
        imagen->setGeometry(QRect(20, 140, 971, 551));
        consola = new QTextEdit(centralWidget);
        consola->setObjectName(QStringLiteral("consola"));
        consola->setGeometry(QRect(1000, 140, 311, 551));
        QFont font;
        font.setPointSize(8);
        consola->setFont(font);
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(1010, 120, 151, 17));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(350, 10, 161, 17));
        aviones = new QLineEdit(centralWidget);
        aviones->setObjectName(QStringLiteral("aviones"));
        aviones->setGeometry(QRect(360, 40, 113, 25));
        MainWindow->setCentralWidget(centralWidget);
        label->raise();
        turnos->raise();
        label_2->raise();
        escritorios->raise();
        label_3->raise();
        estaciones->raise();
        pushButton->raise();
        pushButton_2->raise();
        label_4->raise();
        label_5->raise();
        aviones->raise();
        consola->raise();
        imagen->raise();
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1335, 22));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "Turnos de Simulacion", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Numero de Escritorios", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Estaciones de Servicio", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "Iniciar Simulacion", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MainWindow", "Next", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "Consola", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "Numero de Aviones", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
