#include "colasimpleaviones.h"

colaSimpleAviones::colaSimpleAviones()
{
    this->first = this->last = NULL;
}

void colaSimpleAviones::insertarAvion(nodoAvion *nuevo){
    if(nuevo!=NULL){
        if(first == NULL){
            first = nuevo;
            last = nuevo;
            std::cout<<"se agrego un avion a la cola simple de mantenimiento."<<std::endl;
        }else{
            last->setSiguiente(nuevo);
            nuevo->setSiguiente(NULL);
            last = nuevo;
            std::cout<<"se agrego un avion a la cola simple de mantenimiento"<<std::endl;
        }
    }
}

void colaSimpleAviones::eliminarAvion(){
    if(first != NULL){
        nodoAvion *aux = first->getSiguiente();
        first = NULL;
        delete first;
        first = aux;
    }else{
        std::cout<<"cola simple aviones vacia"<<std::endl;
    }
}
