#include "listasimple.h"

listaSimple::listaSimple()
{
    this->primero = this->ultimo = NULL;
    this->colaAviones = new colaSimpleAviones();
    this->c = 1;
}


void listaSimple::actualizar(){
    //que me devuelva el que esta desocupado
    if(this->primero != NULL){
        nodoSimple  *a = this->primero;
        while(a !=NULL)
        {
            if(a->ocupado()==false)
            {
                //si no esta ocupada le metemos un avion
                a->avion = this->colaAviones->first;
                this->colaAviones->eliminarAvion();
                std::cout<<"el avion entro a mantenimiento"<<std::endl;
                break;
            }
            else if(a->ocupado() == true)
            {
                //pero si esta ocupado tenemos que ver el numero de turnos del avion en el mantenimiento;
                int turnos = a->avion->getTurnosMan();
                if(turnos>1){
                    a->avion->setTurnosMan(turnos-1);
                    std::cout<<"se le ha restado un turno al avion"<<std::endl;
                }else{
                    //tenemos que eliminarlo definitivamente de la lista

                    a->avion = NULL;
                    a->avion = this->colaAviones->first;
                    this->colaAviones->eliminarAvion();//como ya metimos a otro eliminamos de la cola al que este de primero
                    std::cout<<"El avion ha terminado sus turnos lo sacamos del sistema"<<std::endl;
                }
            }
            a = a->siguiente;
        }
    }else{
        std::cout<<"no hay escritorios en la listaSimple"<<std::endl;
    }

}

void listaSimple::insertarUltimo()
{
    nodoSimple *n = new nodoSimple(this->c);
    if(this->primero == NULL){
        this->primero = n;
        this->ultimo = n;
        this->c++;
    }else{
        this->ultimo->siguiente = n;
        this->ultimo = n;
        this->c++;
    }
}

void listaSimple::insertarAlFrente()
{
    nodoSimple *n = new nodoSimple(this->c);
    if(this->primero == NULL)    {
        this->primero = n;
        this->ultimo = n;
        std::cout<<"se inserto un centro de mantenimiento: "<<this->c<<std::endl;
        this->c++;
    }
    else
    {
        n->siguiente = this->primero;
        this->primero = n;
        std::cout<<"se inserto un centro de mantenimiento: "<<this->c<<std::endl;
        this->c++;
    }
}

QString listaSimple::info()
{
    QString i  = "";
    if(primero != NULL)
    {
        nodoSimple *aux = primero;
        while(aux!=NULL)
        {
            if(aux->ocupado()==false)
            {
                i+= "Estacion "+QString::number(aux->n)+" : Libre \n";
                i+= "\t Avion en Mantenimiento: Ninguno \n";
                i+= "\t Turnos Restantes: 0\n";
            }else{
                i+= "Estacion "+QString::number(aux->n)+": Ocupado\n";
                i+= "\t Avion en Mantenimiento:"+aux->avion->getTipo() +"\n";
                i+= "\t Turnos Restantes: "+QString::number(aux->avion->getTurnosMan())+"\n";
            }
            aux = aux->siguiente;
        }
    }
    return i;
}

QString listaSimple::graficar()
{
    QString grafico = "";
    int n = 1;
    grafico = "subgraph listaSimple { rankdir = LR; \n label=\"Lista Simple Mantenimiento\"; \n node[style=filled, fillcolor=lightcyan1,color=black];\n";
    if(this->primero != NULL)
    {
        nodoSimple *aux = this->primero;
        QString t, t1, t2 = "";
        while(aux != NULL)
        {
            t.sprintf("%08p", aux);
            grafico += "\""+t+"\" [shape= \"rect \" ,label = \"Sala de Manteniemiento #"+QString::number(n)+"\"]; \n";
            if(aux->ocupado()==true)
            {
                t2.sprintf("%08p", aux->avion);
                grafico += "\""+t2+"\" [shape= \"rect \" ,label = \"Avión tipo:"+aux->avion->getTipo()+"\n Turnos En Mantenimiento: "+QString::number(aux->avion->getTurnosMan())+"\"]; \n";
                grafico+= "\""+t+"\" -> \""+t2+"\" \n";
            }
            if(aux->siguiente != NULL)
            {
                t1.sprintf("%08p", aux->siguiente);
                grafico += "\""+t1+"\" [shape= \"rect \" ,label = \"Sala de Manteniemiento #"+QString::number(n+1)+"\"]; \n";
                grafico+= "\""+t+"\" -> \""+t1+"\" \n";
            }
            aux = aux->siguiente;
            n++;
        }
    }
    grafico+="}\n";
    return grafico;
}
