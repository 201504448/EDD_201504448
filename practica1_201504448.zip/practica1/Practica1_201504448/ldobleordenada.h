#ifndef LDOBLEORDENADA_H
#define LDOBLEORDENADA_H
#include <nodoescritorio.h>
#include <iostream>
#include <nodopersona.h>
#include <ldoblecircular.h>
using namespace std;
struct lDobleOrdenada
{
public:
    lDobleOrdenada();
    nodoEscritorio *primero, *ultimo;
    void insertar(char l);//insertar escritorios
    void insertarPersona(nodoPersona *p);
    void llenar();
    bool llena();
    bool vacia();
    void mostrar();
    void actualizar(lDobleCircular *lista);
    QString graficar();
    QString info();
};

#endif // LDOBLEORDENADA_H
