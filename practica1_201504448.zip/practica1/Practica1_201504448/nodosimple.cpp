#include "nodosimple.h"

nodoSimple::nodoSimple(int n)
{
    this->avion = NULL;
    this->siguiente = NULL;
    this->n = n;
}

bool nodoSimple::ocupado(){
    if(this->avion==NULL) return false;
    return true;
}
