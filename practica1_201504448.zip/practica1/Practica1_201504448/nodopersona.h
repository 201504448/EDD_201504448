#ifndef NODOPERSONA_H
#define NODOPERSONA_H
#include <iostream>

struct nodoPersona
{
public:
    nodoPersona(int maletas, int documentos, int turnosRegistro, int id);
    void setMaletas(int maletas);
    void setDocumentos(int documentos);
    void setTurnos(int turnosRegistro);
    void setSiguiente(nodoPersona *siguiente);

    int getMaletas();
    int getDocumentos();
    int getTurnos();
    int getId();
    nodoPersona *getSiguiente();

private:
    int maletas;
    int documentos;
    int turnosRegistro;
    int id;
    nodoPersona *siguiente;
};

#endif // NODOPERSONA_H
