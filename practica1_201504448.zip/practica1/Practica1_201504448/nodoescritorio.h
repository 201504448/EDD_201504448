#ifndef NODOESCRITORIO_H
#define NODOESCRITORIO_H
#include <nodopersona.h>
#include <colaescritorio.h>
#include <pila.h>
#include <iostream>
struct nodoEscritorio
{
public:
    nodoEscritorio();
    bool ocupado();
    nodoEscritorio *sigte;
    nodoEscritorio *anterior;
    colaEscritorio *cola;
    pila *pilaDocumentos;
    char dato;


};

#endif // NODOESCRITORIO_H
