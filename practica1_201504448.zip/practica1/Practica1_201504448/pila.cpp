#include "pila.h"

pila::pila()
{
    cabeza = NULL;
}

nodo::nodo(int dato)
{
    this->dato = dato;
    siguiente = NULL;
}

void pila::insertar(int dato){
    nodo *n = new nodo(dato);
    if(this->cabeza == nullptr){
        this->cabeza = n;
        this->cabeza->siguiente = NULL;
        std::cout<<cabeza<<std::endl;
    }else{
        n->siguiente = cabeza;
        cabeza = n;
    }
}

nodo *pila::getCabeza(){
    return this->cabeza;
}

void pila::eliminar(){
    if(this->cabeza != NULL){
        nodo *aux = this->cabeza;
        cabeza = nullptr;
        delete cabeza;
        cabeza = aux->siguiente;
    }else{
        std::cout<<"Pila Vacía"<<std::endl;
    }
}

QString pila::graficar()
{
    QString grafico = "";
    grafico = "subgraph pilaDocumentos { rankdir = UD;\n node[style=\"filled\", color=\"blue\"];";
    if(cabeza != NULL)
    {
        nodo *a = cabeza;
        nodo *next = NULL;
        QString t,t1 = "";
        while(a!=NULL)
        {
            grafico+="\""+ t.sprintf("%08p", a)+"\"[shape=\"folder\", label = Documento: "+QString::number(a->getDato())+" ]; \n";
            if(a->siguiente != NULL){
                next = a->siguiente;
                grafico+="\""+ t1.sprintf("%08p", next)+"\"[shape=\"folder\", label = Documento: "+QString::number(a->getDato())+"]; \n";
                grafico+= t.sprintf("%08p", a) + " -> "+t1.sprintf("%08p", next);
            }
            a = a->siguiente;
        }
    }
    grafico += "}\n";
    return grafico;
}

int nodo::getDato(){
    return this->dato;
}

void pila::vaciar()
{
    this->cabeza = NULL;
    delete this->cabeza;
}

