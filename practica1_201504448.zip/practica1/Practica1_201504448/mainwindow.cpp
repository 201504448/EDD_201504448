#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QColorDialog>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Airport Simulator 1.0");
    ui->menuBar->setNativeMenuBar(false);
    cPas = new colaSimplePasajeros();
    cDoble = new colaDoble();
    ldo = new lDobleOrdenada();
    ldCMaletas = new lDobleCircular();
    lMan = new listaSimple();
    archivo = new Archivo();

//    QColor color = QColorDialog::(Qt::black,this);
    QColor color = Qt::black;
    QPalette palette;
    palette.setColor(QPalette::Base,color);
    if(color.isValid())
        ui->consola->setPalette(palette);
    QColor color1 = Qt::white;
        if(color1.isValid())
            ui->consola->setTextColor(color1);
    ui->consola->setLineWrapMode(QTextEdit::NoWrap);

}

MainWindow::~MainWindow()
{
    delete ui;
}

QString MainWindow::info()
{
    QString n = QString::number(c);
    QString i = "------------Turno "+n+"--------\n";
    i += "Arribo Avión "+n+"\n Avion desabordando: ";
    if(cDoble->eliminado!=NULL){
        i+= cDoble->ultimo->getTipo()+"\n";
    }else{
        i+="ninguno \n";
    }
    i+= "-----Escritorios de Registro-------\n";
    i+=ldo->info()+"\n -------------------------\n";
    i+= "///////Estaciones de Servicio//////\n";
    i+=lMan->info();+"\n ////////////////////////// \n";
    i+="Cantidad De maletas Actualmente en el sistema: "+QString::number(ldCMaletas->n)+"\n";
    i+="Turnos Restantes: "+QString::number(turnos)+"\n ";
    i+="**********Fin del Turno: "+n+"*************\n";
    c++;
    return i;
}

void MainWindow::on_pushButton_clicked()
{
    if(!ui->turnos->text().isEmpty() && !ui->estaciones->text().isEmpty() && !ui->escritorios->text().isEmpty() && !ui->aviones->text().isEmpty() ) {
        turnos = ui->turnos->text().toInt();
        estaciones = ui->estaciones->text().toInt();
        escritorios = ui->escritorios->text().toInt();
        aviones = ui->aviones->text().toInt();
        int n = 0;
        for(int i = 0; i < escritorios;i++){
            n = 65 + (rand() % (90 - 65));
            ldo->insertar((char)(n));
        }
        for(int i = 0; i < estaciones; i++){
            lMan->insertarAlFrente();
        }
        cDoble->insertar();//ya ingreso el primer avion
        aviones--;
        ui->aviones->setText(QString::number(aviones));

        ui->pushButton->setVisible(false);
        QString grafoFinal = "digraph g {rankdir=UD; \n";
        grafoFinal+=cPas->graficar() +"\n"+ cDoble->graficar() +"\n"+ldo->graficar()+"\n"+ldCMaletas->graficar()+"\n"+lMan->graficar();
        grafoFinal+="}\n";
        archivo->generarGrafico("grafoFinal",grafoFinal);
        this->verArchivo("grafoFinal.png");
        ui->consola->append(this->info());
    }else{
        QMessageBox m;
        m.setText("Hace Falta Ingresar algun dato");
        m.exec();
    }

}

void MainWindow::on_pushButton_2_clicked()
{
    //boton siguiente;
    if(aviones>0 && turnos > 0){
        cDoble->insertar();
        if(cDoble->actualizar()){
            //quiere decir que si saco un avion de la cola
            nodoAvion *e = cDoble->getEliminado();
            //lo tenemos que enviar a la cola simple de la lista simple de aviones
            e->setSiguiente(NULL);
            lMan->colaAviones->insertarAvion(e);
            //tenemos que ver si existe una sala de mantenimiento disponible
            lMan->actualizar();
            for(int i=0;i<e->getPasajeros();i++){
                //por cada pasajero debemos ingresarlo a la cola simple de pasajeros
                cPas->insertar();

            }
            if(ldo->vacia() == true){
                //while(ldo->llena()==false)
                //{
                    cPas->eliminar();
                   // ldo->insertarPersona(cPas->first);
                    cPas->mostrar();
                    //tenemos que insertar las maletas que traiga este cuate
                    /*for(int i = 0; i<cPas->first->getMaletas();i++){
                        ldCMaletas->insertar();
                    }
                    cPas->eliminar();
                    std::cout<<"supuestamente en el main ya elimino en la cola de pasajeros"<<std::endl;
                    cPas->mostrar();

                    ldo->actualizar(this->ldCMaletas);*/
                //}
            }else{
                ldo->actualizar(this->ldCMaletas);
                //while(ldo->llena()==false)
                //{
                    cPas->eliminar();
                    cPas->mostrar();
                    /*ldo->insertarPersona(cPas->first);
                    //tenemos que insertar las maletas que traiga este cuate
                    for(int i = 0; i<cPas->first->getMaletas();i++){
                        ldCMaletas->insertar();
                    }
                    cPas->eliminar();
                    ldo->actualizar(this->ldCMaletas);*/
                //}
            }

        }else{
            //si no eliminamos aviones igual tenemos que validar que todas las demas estructuras se esten actualizando
            lMan->actualizar();
            if(cPas->first!=NULL){
                //quiere decir que hay pasajeros aun en la cola del avion anterior
                /*ldo->actualizar(this->ldCMaletas);
                while(ldo->llena()==false)
                {
                    cPas->mostrar();
                    ldo->insertarPersona(cPas->first);
                    //tenemos que insertar las maletas que traiga este cuate
                    for(int i = 0; i<cPas->first->getMaletas();i++){
                        ldCMaletas->insertar();
                    }
                    cPas->eliminar();

                    ldo->actualizar(this->ldCMaletas);
                }*/
                cPas->eliminar();//no estaba
                cPas->mostrar();//no estaba
            }else{
                std::cout<<"no hay pasajeros en cola en el mainwindow"<<std::endl;
            }
        }
    }else{


    }
    this->aviones=aviones-1;
    this->turnos = this->turnos-1;
    if(aviones > 0 && turnos >0){
        ui->aviones->setText(QString::number(aviones));
        ui->turnos->setText(QString::number(turnos));

    }else{
        QMessageBox m;
        m.setText("Ya no existen aviones o turnos para poder continuar la simulacion");
        ui->pushButton_2->setVisible(false);
    }
    QString grafoFinal = "digraph g {rankdir=UD; \n";
    grafoFinal+=cPas->graficar() +"\n"+ cDoble->graficar() +"\n"+ldo->graficar()+"\n"+ldCMaletas->graficar()+"\n"+lMan->graficar();
    grafoFinal+="}\n";
    archivo->generarGrafico("grafoFinal",grafoFinal);
    this->verArchivo("grafoFinal.png");
    ui->consola->append(this->info());
}


void MainWindow::verArchivo(QString nombre){
    QString file = nombre;
    if(QFile::exists(file)){
        ui->imagen->setText("");
        QUrl Uri ( QString ( "file://%1" ).arg ( file ) );
        QImage image = QImageReader ( file ).read();

        QTextDocument * textDocument = ui->imagen->document();
        textDocument->addResource( QTextDocument::ImageResource, Uri, QVariant ( image ) );
        QTextCursor cursor = ui->imagen->textCursor();
        QTextImageFormat imageFormat;
        imageFormat.setWidth( image.width() );
        imageFormat.setHeight( image.height() );
        imageFormat.setName( Uri.toString() );
        cursor.insertImage(imageFormat);
        ui->imagen->repaint();
    }else{
        std::cout<<"imagen no existe"<<std::endl;
    }


}
