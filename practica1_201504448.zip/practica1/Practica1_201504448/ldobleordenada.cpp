#include "ldobleordenada.h"

lDobleOrdenada::lDobleOrdenada(){
    this->primero = this->ultimo = NULL;
}

void lDobleOrdenada::mostrar(){
    if(primero != NULL)
    {
        nodoEscritorio *a = primero;
        while(a != NULL)
        {
            cout<<"Letra: "<<a->dato<<endl;
            a = a->sigte;
        }
    }else{
        cout<<"Lista Doble ordenada vacía"<<endl;
    }
}

QString lDobleOrdenada::info()
{
    QString i = "";
    if(this->primero!=NULL){
        nodoEscritorio *a = this->primero;
        while(a!=NULL){
            QString l = "";
            l+=a->dato;
            if(a->ocupado()==false){
                i+="Escritorio :"+l+" libre \n";
                i+="\t Pasajero atendido: ninguno\n";
                i+="\t Turnos Restantes: 0 \n";
                i+="\t Cantidad de Documentos: 0\n";
            }else{
                i+="Escritorio :"+l+" ocupado \n";
                i+="\t Pasajero atendido: "+QString::number(a->cola->primero->getId())+"\n";
                i+="\t Turnos Restantes: "+QString::number(a->cola->primero->getTurnos())+"\n";
                i+="\t Cantidad de Documentos: "+QString::number(a->cola->primero->getDocumentos())+"\n";
            }
            a = a->sigte;
        }
    }else{

    }
    return i;

}

QString lDobleOrdenada::graficar()
{
    QString grafico = "";
    grafico = "subgraph lDobleOrdenada { rankdir = LR;\n label = \"Lista Doble Ordenada Escritorios\"; \n node[style=filled, fillcolor=lightcyan1,color=black];\n";
    if(primero!= NULL)
    {
        QString t,t1,t2,t3 ,t4= "";
        nodoEscritorio *a = primero;
        nodoEscritorio *next = NULL;

        while(a!=NULL)
        {
            t.sprintf("%08p", a);
            grafico += "\""+(t)+"\" [shape=\"signature\" , label = \" Escritorio: "+a->dato+"\"]; \n";
            if(a->sigte!=NULL){
                next = a->sigte;
                t1.sprintf("%08p", next);
                grafico += "\""+t1+"\" [shape=\"signature\" , label = \" Escritorio: "+next->dato+"\"]; \n";
                grafico += "\""+t+"\" -> \""+t1+"\" \n";
                t2.sprintf("%08p",next->anterior);
                grafico += "\""+t1+"\" -> \""+t2+"\" \n";
            }
            //por cada nodo debo graficar su cola de elementos
            if(a->cola->primero!=NULL){
                t3.sprintf("%08p",a->cola->primero);

                grafico+=a->cola->graficar()+"\n";
                grafico+="\""+t+"\" -> \""+t3+"\"";
            }

            if(a->pilaDocumentos->getCabeza() != NULL){
                t4.sprintf("%08p",a->pilaDocumentos->getCabeza());
                grafico+=a->pilaDocumentos->graficar()+"\n";
                grafico+="\""+t+"\" -> \""+t4+"\"";
            }
            a = a->sigte;
        }
    }
    grafico += "}\n";
    return grafico;
}


void lDobleOrdenada::insertarPersona(nodoPersona *p){
    if(this->primero!=NULL){
        nodoEscritorio *temp = this->primero;
            //primero analizamos si su cola no esta llena
        while(temp!=NULL){
            if(temp->cola->llena()==false){
                if(p != NULL){
                    temp->cola->insertar(p);
                    std::cout<<"se ha insertado en la doble ordenada en su cola un pasajero"<<std::endl;
                    break;
                }else{
                    std::cout<<"no se puede insertar un elemento nulo en la cola de doble ordenada"<<std::endl;
                    break;
                }
            }
            temp = temp->sigte;
        }
    }
}

void lDobleOrdenada::insertar(char l)
{
    nodoEscritorio *n = new nodoEscritorio();
    n->dato = l;
    int d = (int) l;
    int daux = 0;
    if(this->primero==NULL){
        this->ultimo = this->primero = n;
    }else{
        daux = (int)this->primero->dato;
        if(this->primero == this->ultimo){
            if(daux>d){
                //va antes
                this->primero->anterior = n;
                n->sigte = this->primero;
                this->primero = n;
                n->anterior=NULL;
            }else{
                this->ultimo->sigte=n;
                n->anterior = this->ultimo;
                this->ultimo=n;
            }
        }else{
            nodoEscritorio *aux = this->primero;
            nodoEscritorio *anterior = NULL;
            while(aux!=NULL)            {
                daux = (int)aux->dato;
                if(daux>d){
                    if(aux == this->primero){
                        primero->anterior = n;
                        n->sigte = primero;
                        primero = n;
                        break;
                    }else if (aux == this->ultimo){
                        anterior = this->ultimo->anterior;
                        anterior->sigte = n;
                        n->anterior = anterior;
                        n->sigte = ultimo;
                        ultimo->anterior = n;
                        break;
                    }else{
                        anterior = aux->anterior;
                        anterior->sigte = n;
                        n->anterior = anterior;
                        n->sigte = aux;
                        aux->anterior = n;
                        break;
                    }

                }else if(daux < d && aux == ultimo){
                    ultimo->sigte = n;
                    n->anterior = ultimo;
                    ultimo = n;
                    break;
                }
                aux = aux->sigte;
            }
        }
    }


}

void lDobleOrdenada::actualizar(lDobleCircular *lista){
    //tenemos que actualizar todos los escritorios
    if(this->primero!=NULL){
        nodoEscritorio *temp = this->primero;
        while(temp != NULL){
            if(temp->ocupado() == true){
                //si el nodo esta ocupado
                if(temp->cola->actualizar())
                {
                    temp->pilaDocumentos->vaciar();
                    int maletas = temp->cola->eliminado->getMaletas();
                    for(int i = 0;i<maletas;i++){
                        lista->eliminar();
                    }
                    std::cout<<"se eliminaro: "<<maletas<<" maletas"<<std::endl;
                }

            }
            temp = temp->sigte;
        }
    }

}

bool lDobleOrdenada::vacia()
{
    bool l = false;
    if(this->primero!=NULL){
        if(this->primero->cola->primero==NULL){
            l = true;
        }
    }
    return l;
}

bool lDobleOrdenada::llena()
{
    bool full = false;
    if(this->primero!=NULL){
        nodoEscritorio *aux = this->primero;
        while( aux != NULL){
            if(aux->cola->llena()==true){
                full = full * true;
            }else{
                full = full * false;
            }
            aux = aux->sigte;
        }
    }
}

