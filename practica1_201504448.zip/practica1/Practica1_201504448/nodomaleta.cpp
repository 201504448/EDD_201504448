#include "nodomaleta.h"

nodoMaleta::nodoMaleta()
{

    this->siguiente = nullptr;
    this->anterior = nullptr;
}

void nodoMaleta::setAnterior(nodoMaleta *n)
{
    this->anterior = n;
}


void nodoMaleta::setSiguiente(nodoMaleta *n)
{
    this->siguiente = n;
}

nodoMaleta * nodoMaleta::getAnt(){
    return this->anterior;
}

nodoMaleta * nodoMaleta::getSigte(){
    return this->siguiente;
}
