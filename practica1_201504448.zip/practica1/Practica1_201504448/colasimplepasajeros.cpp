#include "colasimplepasajeros.h"

colaSimplePasajeros::colaSimplePasajeros()
{
    this->first = this->last = this->eliminado= NULL;
}

void colaSimplePasajeros::eliminar()
{
    if(first != NULL){
        nodoPersona *aux = first->getSiguiente();
        first = NULL;
        delete first;
        first = aux;
    }else{
        std::cout<<"cola simple pasajeros vacia"<<std::endl;
    }

}

QString colaSimplePasajeros::generarDatos()
{
    QString datos = "";
    int n = 0;
    datos=QString::number(this->id);
    this->id++;
    //maletas de 1 a 4
    n = 1 + (rand() % (4 - 1 + 1));
    datos += ","+QString::number(n);
    //documentos de 1 a 10
    n = 1 + (rand()%(10 - 1 + 1));
    datos += ","+QString::number(n);
    //turnos para registro de 1 a 3
    n = 1 + (rand()%(3 - 1 + 1));
    datos += ","+QString::number(n);
    return datos;
}

void colaSimplePasajeros::insertar()
{
    QString datos = this->generarDatos();
    QStringList lista = datos.split(",");
    int maletas = 0, documentos = 0, turnos = 0,id = 0;
    if(lista.size()==4){
        id = lista.at(0).toInt();
        maletas = lista.at(1).toInt();
        documentos = lista.at(2).toInt();
        turnos = lista.at(3).toInt();
    }
    nodoPersona *nuevo = new nodoPersona(maletas,documentos, turnos,id);
    if(first == NULL){
        first = nuevo;
        last = nuevo;
        std::cout<<"se agrego un avion a la cola simple de mantenimiento."<<std::endl;
    }else{
        last->setSiguiente(nuevo);
        nuevo->setSiguiente(NULL);
        last = nuevo;
        std::cout<<"se agrego un avion a la cola simple de mantenimiento"<<std::endl;
    }
}

void colaSimplePasajeros::mostrar()
{
    if(first != NULL){
        nodoPersona *aux = first;
        while(aux != NULL)
        {
            std::cout<<"Persona: "<<aux->getId()<<std::endl;
            aux = aux->getSiguiente();
        }
    }else{
        std::cout<<"cola pasjeros totalmente vacia"<<std::endl;
    }
}

QString colaSimplePasajeros::graficar()
{
    QString grafico = "";
    grafico = "subgraph colaSimple { rankdir = UD;\n label=\"Cola Simple Pasajeros\";\n node[shape=\"rect\", color = \"blue\"];\n";
    if(first!= NULL)
    {
        QString t, t1, t2  = "";
        nodoPersona *a = first;
        nodoPersona *next = NULL;
        while(a!=NULL)
        {
            t.sprintf("%08p", a);
            grafico += "\""+t+"\" [label = \" Id: "+QString::number(a->getId())+"\n Maletas: "+QString::number(a->getMaletas())+" \n Documentos: "+QString::number(a->getDocumentos())+"\n Turnos en Escritorio: "+QString::number(a->getTurnos())+" \"]; \n";
            if(a->getSiguiente()!=NULL){
                next = a->getSiguiente();
                t1.sprintf("%08p", next);
                grafico += "\""+t1+"\" [label = \" Id: "+QString::number(next->getId())+"\n Maletas: "+QString::number(next->getMaletas())+" \n Documentos: "+QString::number(next->getDocumentos())+"\n Turnos en Escritorio: "+QString::number(next->getTurnos())+" \"]; \n";
                grafico += "\""+t+"\" -> \""+t1+"\" \n";

            }
            a = a->getSiguiente();
        }
    }
    grafico += "}\n";
    return grafico;
}
