#ifndef NODOAVION_H
#define NODOAVION_H
#include <QString>

struct nodoAvion
{
public:
    nodoAvion(QString tipo, int pasajeros, int tDesa, int tMan, int id);
    void setPasajeros(int pasajeros);
    void setTurnosDesa(int t);
    void setTurnosMan(int t);
    void setSiguiente(nodoAvion *siguiente);
    void setAnterior(nodoAvion *ante);

    int getTurnosDesa();
    int getTurnosMan();
    int getPasajeros();
    int getId();
    nodoAvion *getSiguiente();
    nodoAvion *getAnterior();
    QString getTipo();

private:
    QString tipo;
    int pasajeros;
    int turnosDesabordaje;
    int turnosMantenimiento;
    int id = 0;
    nodoAvion *siguiente, *anterior;
};

#endif // NODOAVION_H
