#include "nodoavion.h"

nodoAvion::nodoAvion(QString tipo, int pasajeros, int tDesa, int tMan, int id)
{
    this->tipo = tipo;
    this->pasajeros = pasajeros;
    this->turnosDesabordaje = tDesa;
    this->turnosMantenimiento = tMan;
    this->siguiente = this->anterior = NULL;
    this->id = id;
}

nodoAvion* nodoAvion::getSiguiente()
{
    return this->siguiente;
}

nodoAvion * nodoAvion::getAnterior(){
    return this->anterior;
}

void nodoAvion::setSiguiente(nodoAvion *siguiente)
{
    this->siguiente = siguiente;
}

void nodoAvion::setAnterior(nodoAvion *ante){
    this->anterior = ante;
}

void nodoAvion::setPasajeros(int pasajeros)
{
    this->pasajeros = pasajeros;
}

void nodoAvion::setTurnosDesa(int t)
{
    this->turnosDesabordaje = t;
}

void nodoAvion::setTurnosMan(int t)
{
    this->turnosMantenimiento = t;
}

QString nodoAvion::getTipo(){
    return this->tipo;
}

int nodoAvion::getTurnosDesa(){
    return this->turnosDesabordaje;
}

int nodoAvion::getTurnosMan()
{
    return this->turnosMantenimiento;
}

int nodoAvion::getId()
{
    return this->id;
}

int nodoAvion::getPasajeros(){
    return this->pasajeros;
}

