#include "archivo.h"

Archivo::Archivo()
{

}

void Archivo::generarGrafico(QString nombre, QString texto){
    QFile sFile(nombre+".txt");
    if(sFile.open(QFile::WriteOnly | QFile::Text)){
        QTextStream out(&sFile);
        out << texto;
        sFile.flush();
        sFile.close();
    }
    QFile archivo(nombre+".txt");
    QFileInfo info(archivo.fileName());
    const QString nom(info.fileName());
    QString name = nom;
    QString nombre1 = name;
    QString image = name.replace(".txt",".png");
    QProcess proceso ;
    proceso.start("dot -Tpng "+nombre1+" -o "+image);
    proceso.waitForFinished(-1);
    //this->verImagen(ruta+image,nombre);
    QFile ima(image);
    QMessageBox msgBox;
    if(ima.exists()){
        msgBox.setText("Se ha creado el archivo");
        msgBox.exec();
    }else{
        msgBox.setText("No se ha creado el archivo");
        msgBox.exec();
    }

}


