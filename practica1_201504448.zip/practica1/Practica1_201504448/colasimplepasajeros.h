#ifndef COLASIMPLEPASAJEROS_H
#define COLASIMPLEPASAJEROS_H
#include <iostream>
#include <nodopersona.h>
#include <QString>
#include <QStringList>

struct colaSimplePasajeros
{
public:
    colaSimplePasajeros();
    nodoPersona *first, *last,*eliminado;
    void insertar();
    void eliminar();
    void mostrar();
    QString generarDatos();
    QString graficar();
    int id = 1000;

};

#endif // COLASIMPLEPASAJEROS_H
