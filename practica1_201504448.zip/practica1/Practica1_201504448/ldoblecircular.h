#ifndef LDOBLECIRCULAR_H
#define LDOBLECIRCULAR_H
#include <nodomaleta.h>
#include <QString>
#include <iostream>

using namespace std;

struct lDobleCircular
{
public:
    lDobleCircular();
    nodoMaleta *getPrimero();
    nodoMaleta *getUltimo();
    void insertar();
    void eliminar();
    QString graficar();
    int n = 0;
private:
    nodoMaleta *primero, *ultimo;

};

#endif // LDOBLECIRCULAR_H
