#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMessageBox>
#include <coladoble.h>
#include <ldobleordenada.h>
#include <ldoblecircular.h>
#include <colasimplepasajeros.h>
#include <cstdlib>
#include <listasimple.h>
#include <archivo.h>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    int turnos = 0, escritorios = 0, estaciones = 0, aviones = 0, c = 1;
    colaDoble *cDoble;//aviones
    colaSimplePasajeros *cPas;//pasajeros
    lDobleOrdenada *ldo;//escritorios
    lDobleCircular *ldCMaletas;//maletas
    listaSimple *lMan;
    Archivo *archivo;
    void verArchivo(QString nombre);
    QString info();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
