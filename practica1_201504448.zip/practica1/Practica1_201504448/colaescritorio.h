#ifndef COLAESCRITORIO_H
#define COLAESCRITORIO_H
#include <nodopersona.h>
#include <QString>
#include <iostream>

struct colaEscritorio
{
public:
    colaEscritorio();
    void insertar(nodoPersona *n);
    void eliminar();
    bool actualizar();
    bool llena();
    int tamano = 0;
    QString graficar();
    nodoPersona *primero,*ultimo,*eliminado;
};

#endif // COLAESCRITORIO_H
