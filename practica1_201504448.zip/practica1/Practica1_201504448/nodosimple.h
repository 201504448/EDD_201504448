#ifndef NODOSIMPLE_H
#define NODOSIMPLE_H
#include <nodoavion.h>

//estacion de servicio
struct nodoSimple
{
public:
    nodoSimple(int n);
    nodoAvion *avion;
    nodoSimple *siguiente;
    bool ocupado();
    int n;
};

#endif // NODOSIMPLE_H
