#ifndef PILA_H
#define PILA_H
#include <iostream>
#include <QString>

//pila documentos
struct nodo{
public:
    nodo(int dato);
    struct nodo* siguiente;
    int getDato();
private:
    int dato;
};


struct pila
{
public:
    pila();
    void insertar(int dato);
    void eliminar();
    void vaciar();
    QString graficar();
    nodo *getCabeza();
    nodo *cabeza;

};

#endif // PILA_H
