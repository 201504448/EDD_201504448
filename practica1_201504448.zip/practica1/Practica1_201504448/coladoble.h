#ifndef COLADOBLE_H
#define COLADOBLE_H
#include <nodoavion.h>
#include <coladoble.h>
#include <cstdlib>
#include <QStringList>
#include <iostream>


using namespace std ;

struct colaDoble
{
public:
    colaDoble();
    nodoAvion *primero, *ultimo,*eliminado;
    nodoAvion *getFirst();
    nodoAvion *getLast();
    nodoAvion *getEliminado();
    void setEliminado(nodoAvion *e);
    void insertar();
    void mostrar();
    bool actualizar();
    nodoAvion *eliminar();

    QString graficar();
    QString getDatos();
    int id = 0;

};


#endif // COLADOBLE_H
