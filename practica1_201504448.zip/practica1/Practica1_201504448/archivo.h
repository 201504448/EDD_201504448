#ifndef ARCHIVO_H
#define ARCHIVO_H
#include <QFile>
#include <QTextStream>
#include <QFileInfo>
#include <QProcess>
#include <QMessageBox>
#include <QTextEdit>
#include <QImageReader>
#include <iostream>

struct Archivo
{
public:
    Archivo();
    void generarGrafico(QString nombre, QString texto);

};

#endif // ARCHIVO_H
