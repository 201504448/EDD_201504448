#ifndef NODOMALETA_H
#define NODOMALETA_H


struct nodoMaleta
{
public:
    nodoMaleta();

    void setSiguiente(nodoMaleta *n);
    nodoMaleta *getSigte();

    void setAnterior(nodoMaleta *n);
    nodoMaleta *getAnt();

private:

    nodoMaleta *siguiente, *anterior;
};

#endif // NODOMALETA_H
