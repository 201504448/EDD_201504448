#include "ldoblecircular.h"

lDobleCircular::lDobleCircular()
{
    this->primero = this->ultimo = NULL;
    n = 0;
}

void lDobleCircular::insertar(){
    nodoMaleta *n = new nodoMaleta();
    if(primero==NULL){
        primero = ultimo = n;
        primero->setSiguiente(ultimo);
        primero->setAnterior(ultimo);
        ultimo->setSiguiente(primero);
        ultimo->setAnterior(primero);
        this->n++;
    }else{
        ultimo->setSiguiente(n);
        n->setSiguiente(primero);
        n->setAnterior(ultimo);
        ultimo = n;
        this->n++;
    }
}


void lDobleCircular::eliminar(){
    if(primero!=NULL){
        nodoMaleta *eliminado = ultimo;
        nodoMaleta *aux = NULL;
        aux = ultimo->getAnt();
        aux->setSiguiente(primero);
        ultimo = NULL;
        delete ultimo;
        ultimo = aux;
        this->n--;
    }else{
        std::cout<<"Lista doble circular de maletas vacía"<<std::endl;
    }
}


QString lDobleCircular::graficar(){
    QString grafico = "";
    grafico = "subgraph ldobleCircular { rankdir = LR; \n label=\"Lista Circular Maletas\"; \n node[style=filled, fillcolor=lightcyan1,color=black];\n";
    if(primero!= NULL)
    {
        QString t,t1,t2,t3 = "";
        nodoMaleta *a = primero;
        nodoMaleta *next = NULL;
        int n = 1;
        while(a!=ultimo)
        {
            t.sprintf("%08p", a);
            grafico += "\""+(t)+"\" [shape=\"component\" , label = \" Maleta: "+QString::number(n)+"\"]; \n";
            next = a->getSigte();
            t1.sprintf("%08p", next);
            grafico += "\""+t1+"\" [shape=\"component\" , label = \" Escritorio: "+QString::number(n+1)+"\"]; \n";
            grafico += "\""+t+"\" -> \""+t1+"\" \n";
            t2.sprintf("%08p",next->getAnt());
            grafico += "\""+t1+"\" -> \""+t2+"\" \n";
            a = a->getSigte();
            n++;
        }
        if(a == ultimo){
            t1 = t="";
            t.sprintf("%o8p",ultimo); //ultimo
            t1.sprintf("%08p",primero);//primero
            grafico += "\""+t+"\" [shape=\"component\" , label = \" Maleta: "+QString::number(n)+"\"]; \n";
            grafico += "\""+t+"\" -> \""+t1+"\"   \n  \""+t1+"\" -> \""+t+"\" \n";
            n++;
        }
    }
    grafico += "}\n";
    return grafico;
}

nodoMaleta * lDobleCircular::getPrimero(){
    return this->primero;
}

nodoMaleta * lDobleCircular::getUltimo(){
    return this->ultimo;
}


