#include "nodoescritorio.h"

nodoEscritorio::nodoEscritorio()
{
    this->anterior = this->sigte = NULL;
    this->dato = ' ';
    this->cola = new colaEscritorio();
    this->pilaDocumentos = new pila();
    //std::cout<<"se creo una cola de escritorio y una pila de documentos nueva"<<std::endl;
}

bool nodoEscritorio::ocupado()
{
    if(this->cola->primero!=NULL)return true;
    return false;
}
