#include "colaescritorio.h"

colaEscritorio::colaEscritorio()
{
    this->primero = this->ultimo = NULL;
    this->tamano = 0;
}


void colaEscritorio::insertar(nodoPersona *n){
    if(!llena()){
        if(this->primero == NULL){
            this->primero = n;
            this->ultimo = n;
            this->ultimo->setSiguiente(NULL);
            this->tamano++;
        }else{
            this->ultimo->setSiguiente(n);
            n->setSiguiente(NULL);
            this->ultimo=n;
            this->tamano++;
        }
    }else{
        std::cout<<"cola llena"<<std::endl;
    }
}


QString colaEscritorio::graficar()
{
    std::cout<<"metodo graficar cola de escritorio"<<std::endl;
    QString grafico = "";
    grafico = "subgraph g {\n";
    if(primero!= NULL)
    {
        nodoPersona *a = primero;
        nodoPersona *next = NULL;
        QString t, t1, t2 = "";
        while(a!=NULL)
        {
            t.sprintf("%08p", a);

            grafico += "\""+t+"\" [label = \" Id: "+QString::number(a->getId())+"\n Maletas: "+QString::number(a->getMaletas())+" \n Documentos: "+QString::number(a->getDocumentos())+"\n Turnos en Escritorio: "+QString::number(a->getTurnos())+" \"]; \n";
            if(a->getSiguiente()!=NULL){
                next = a->getSiguiente();
                t1.sprintf("%08p", next);
                grafico += "\""+t1+"\" [label = \" Id: "+QString::number(next->getId())+"\n Maletas: "+QString::number(next->getMaletas())+" \n Documentos: "+QString::number(next->getDocumentos())+"\n Turnos en Escritorio: "+QString::number(next->getTurnos())+" \"]; \n";
                grafico+= "\""+t+"\" -> \""+t1+"\" \n";
            }
            a = a->getSiguiente();
        }
    }
    else
    {
        std::cout<<"cola de escritorio vacia"<<std::endl;
    }
    grafico += "}\n";
    return grafico;
}

bool colaEscritorio::llena(){
    if(this->tamano<12)return false;
    return true;
}

void colaEscritorio::eliminar()
{
    if(this->primero!=NULL){
        eliminado = primero;
        primero = NULL;
        delete primero;
        primero = eliminado->getSiguiente();
        this->tamano--;
    }else{
        this->tamano = 0;
        std::cout<<"cola escritorio libre"<<std::endl;
    }
}

bool colaEscritorio::actualizar()
{
    if(this->primero!=NULL){
        if(this->primero->getTurnos()>1){
            int turnos = this->primero->getTurnos();
            this->primero->setTurnos(turnos-1);
            return false;
        }else{
            //tenemos que sacarlo de la cola
            this->eliminar();
            return true;
        }
    }
}
