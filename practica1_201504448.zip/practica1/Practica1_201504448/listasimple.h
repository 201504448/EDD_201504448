#ifndef LISTASIMPLE_H
#define LISTASIMPLE_H
#include <nodosimple.h>
#include <colasimpleaviones.h>
#include <iostream>
struct listaSimple
{
public:
    listaSimple();
    nodoSimple *primero, *ultimo;
    colaSimpleAviones *colaAviones;
    void insertarUltimo();
    void insertarAlFrente();
    void actualizar();
    QString graficar();
    QString info();
    int c = 0;
};

#endif // LISTASIMPLE_H
