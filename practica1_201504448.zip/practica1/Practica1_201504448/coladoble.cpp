#include "coladoble.h"

colaDoble::colaDoble()
{
    this->primero = this->ultimo = this->eliminado = NULL;
}

QString colaDoble::getDatos()
{
    QString datos = "";
    int n = 0;
    int n1 = 0;
    n = 1 + (rand()% (3 - 1 +1));
    if(n==1){
        //de 5 a 10 pasajeros
        n = 5 + (rand() % (10 - 5 + 1));

        //mantenimiento
        n1 = 1 + (rand()%(3 - 1 + 1));

        datos = "pequeño,"+QString::number(n)+",1,"+QString::number(n1);

        cout << "pequeño" <<" pasajeros: "<<n<<" Mantenimiento "<<n1<<endl;
    }
    else if(n == 2)
    {
        //de 15 a 25 pasajeros
        n =15 + (rand() % (25 - 15 + 1));

        //mantenimiento
        n1 = 2 + (rand() % (4 - 2 + 1));

        datos = "mediano,"+QString::number(n)+",2,"+QString::number(n1);

        cout << "mediano" <<" pasajeros: "<<n<<" Mantenimiento "<<n1<<endl;
    }
    else if(n == 3)
    {
        //de 30 a 40 pasajeros
        n = 30 + (rand() % (40 - 30 + 1));

        //mantenimiento
        n1 = 3 + (rand()%(6 - 3 + 1));

        datos = "grande,"+QString::number(n)+",3,"+QString::number(n1);

        cout << "grande" <<" pasajeros: "<<n<<" Mantenimiento "<<n1<<endl;
    }

    return datos;
}

nodoAvion *colaDoble::eliminar(){
    nodoAvion *r = NULL;
    if(primero != NULL){
        r = primero;
        if(primero->getSiguiente()!=NULL){
            nodoAvion *n = r->getSiguiente()->getAnterior();
            n = NULL;
            primero = NULL;
            delete primero;
            primero = r->getSiguiente();
        }else{
            primero = NULL;
            ultimo = NULL;
            delete primero;
            delete ultimo;
        }
    }
    return r;
}

void colaDoble::insertar(){
    QString datos;
    datos = this->getDatos();
    int tDesa, tMan, pasajeros;
    QString tipo = "";
    QStringList l = datos.split(",");
    if(l.size() == 4){
        tipo = l.at(0);
        pasajeros = l.at(1).toInt();
        tDesa = l.at(2).toInt();
        tMan = l.at(3).toInt();
    }
    nodoAvion *nuevo = new nodoAvion(tipo,pasajeros,tDesa,tMan,id);
    id++;
    if(primero == NULL){
        primero = nuevo;
        ultimo = primero;
    }else{
        ultimo->setSiguiente(nuevo);
        nuevo->setAnterior(ultimo);
        nuevo->setSiguiente(NULL);
        ultimo = nuevo;
    }

}

void colaDoble::mostrar(){
    if(primero!=NULL){
        nodoAvion *a = primero;
        while(a !=NULL){
            //cout<<a->getTipo().toStdString()<<" pasajeros: "<<a->getPasajeros()<<endl;
            cout<<"nodo: "<<a<<endl;
            a = a->getSiguiente();
        }
    }else{
        cout<<"cola vacía"<<std::endl;
    }
}

bool colaDoble::actualizar(){
    if(primero!=NULL){
        int actuales = primero->getTurnosDesa();
        if(primero->getTurnosDesa()>1){
            primero->setTurnosDesa(actuales-1);
            return false;
        }else {
            //tenemos que eliminarlo de la lista
            primero->setTurnosDesa(actuales-1);
            nodoAvion *e = this->eliminar();
            this->setEliminado(e);
            return true;
        }
    }
}

void colaDoble::setEliminado(nodoAvion *e){
    this->eliminado = e;
}

nodoAvion *colaDoble::getEliminado(){
    return this->eliminado;
}

QString colaDoble::graficar(){
    QString grafico = "";
    grafico = "subgraph coladoble { rankdir = LR; \n label=\"Cola Doble Aviones\"; \n node[style=filled, fillcolor=skyblue,color=black];\n";
    if(primero!= NULL)
    {
        QString t,t1,t2 = "";
        nodoAvion *a = primero;
        nodoAvion *next = NULL;

        while(a!=NULL)
        {
            t.sprintf("%08p", a);
            grafico += "\""+(t)+"\" [shape=\"cds\" , label = \" Tipo: "+a->getTipo()+"\n Pasajeros: "+QString::number(a->getPasajeros())+" \n Turnos en Desabordaje: "+QString::number(a->getTurnosDesa())+"\n Turnos de mantenimiento: "+QString::number(a->getTurnosMan())+" \"]; \n";
            if(a->getSiguiente()!=NULL){
                next = a->getSiguiente();
                t1.sprintf("%08p", next);
                grafico += "\""+t1+"\" [shape=\"cds\" , label = \" Tipo: "+next->getTipo()+"\n Pasajeros: "+QString::number(next->getPasajeros())+" \n Turnos en Desabordaje: "+QString::number(next->getTurnosDesa())+"\n Turnos de mantenimiento: "+QString::number(next->getTurnosMan())+" \"]; \n";
                grafico += "\""+t+"\" -> \""+t1+"\" \n";
                t2.sprintf("%08p",next->getAnterior());
                grafico += "\""+t1+"\" -> \""+t2+"\" \n";
            }
            a = a->getSiguiente();
        }
    }
    grafico += "}\n";
    return grafico;
}

nodoAvion *colaDoble::getLast(){
    return this->ultimo;
}

nodoAvion *colaDoble::getFirst(){
    return this->primero;
}
