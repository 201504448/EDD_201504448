#ifndef COLASIMPLEAVIONES_H
#define COLASIMPLEAVIONES_H
#include <nodoavion.h>
#include <iostream>

class colaSimpleAviones
{
public:
    colaSimpleAviones();
    nodoAvion *first, *last;
    void insertarAvion(nodoAvion *nuevo);
    void eliminarAvion();
    QString graficar();
};

#endif // COLASIMPLEAVIONES_H
