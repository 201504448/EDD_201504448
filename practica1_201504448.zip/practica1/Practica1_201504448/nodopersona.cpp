#include "nodopersona.h"

nodoPersona::nodoPersona(int maletas, int documentos, int turnosRegistro, int id)
{
    this->maletas = maletas;
    this->documentos = documentos;
    this->turnosRegistro = turnosRegistro;
    this->siguiente =  NULL;
    this->id = id;

}

void nodoPersona::setDocumentos(int documentos)
{
    this->documentos = documentos;
}

void nodoPersona::setMaletas(int maletas)
{
    this->maletas = maletas;
}

void nodoPersona::setTurnos(int turnosRegistro)
{
    this->turnosRegistro = turnosRegistro;
}

void nodoPersona::setSiguiente(nodoPersona *siguiente)
{
    this->siguiente = siguiente;
}

int nodoPersona::getDocumentos()
{
    return this->documentos;
}

int nodoPersona::getMaletas()
{
    return this->maletas;
}

int nodoPersona::getTurnos()
{
    return this->turnosRegistro;
}

nodoPersona * nodoPersona::getSiguiente()
{
    return this->siguiente;
}

int nodoPersona::getId()
{
    return this->id;
}
